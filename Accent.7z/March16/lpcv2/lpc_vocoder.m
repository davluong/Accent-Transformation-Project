%clear all;
%initialize
fs_new = 8000;
L = 40;%ms frame size
R=10; %ms frame overlap
L_index = round(L/1000*fs_new) ;
R_index = round(R/1000*fs_new) ;
p = 200;
%library
[s_out_aa,As_aa,Gs_aa] = lpc_out(L_index,R_index,p,'aa.wav',fs_new);
[s_out_ah,As_ah,Gs_ah] = lpc_out(L_index,R_index,p,'ah.wav',fs_new);
[s_out_ur,As_ur,Gs_ur] = lpc_out(L_index,R_index,p,'ur.wav',fs_new);
[s_out_aw,As_aw,Gs_aw] = lpc_out(L_index,R_index,p,'aw.wav',fs_new);
[s_out_uh,As_uh,Gs_uh] = lpc_out(L_index,R_index,p,'uh.wav',fs_new);
[s_out_ehg,As_ehg,Gs_ehg] = lpc_out(L_index,R_index,p,'ehg.wav',fs_new);
[s_out_ee,As_ee,Gs_ee] = lpc_out(L_index,R_index,p,'ee.wav',fs_new);
[s_out_ih,As_ih,Gs_ih] = lpc_out(L_index,R_index,p,'ih.wav',fs_new);

% figure;
% h = pcolor(As_aa);
% set(h, 'EdgeColor', 'none');
% figure;
% h = pcolor(As_ah);
% set(h, 'EdgeColor', 'none');
%audiowrite('C:\Users\ADM�N\Desktop\dsp\proje\lpc_vocoder\dnm.wav',s_out_ah,fs_new);
%%
[yraw2,fs2] = audioread('all_in_one_sentence.wav');
figure;
plot(yraw2);

ask = yraw2(1:45000);
bob = yraw2(45000:69000);
trouble = yraw2(315000:350000);

y_filtered2 = highpass_filter(ask(:,1),fs2);
y2 = resample(y_filtered2,fs_new,fs2);%downsample to 8kHZ
[As2,Gs2,nframes2,exct2]=lpc_analysis(y2,1,length(y2),L_index,R_index,p);
[p1m2,pitch2]=gen_pitch(y2,fs_new,L_index,R_index,nframes2);
As2(:,40:65) = As_ah(:,60:85);
Gs2(40:65) = Gs_ah(60:85);
[e2]=create_excitation_signal(nframes2,R_index,pitch2);
[s2]=synthesize_speech(1,length(y2),L_index,R_index,nframes2,1,e2,Gs2,As2,p,0,hamming(L_index)');
%%
y_filtered2 = highpass_filter(bob(:,1),fs2);
y2 = resample(y_filtered2,fs_new,fs2);%downsample to 8kHZ
[As2,Gs2,nframes2,exct2]=lpc_analysis(y2,1,length(y2),L_index,R_index,p);
[p1m2,pitch2]=gen_pitch(y2,fs_new,L_index,R_index,nframes2);
As2(:,7:17) = As_aw(:,60:70);
Gs2(7:17) = Gs_aw(60:70);
[e3]=create_excitation_signal(nframes2,R_index,pitch2);
[s3]=synthesize_speech(1,length(y2),L_index,R_index,nframes2,1,e3,Gs2,As2,p,0,hamming(L_index)');

%%
y_filtered2 = highpass_filter(trouble(:,1),fs2);
y2 = resample(y_filtered2,fs_new,fs2);%downsample to 8kHZ
[As2,Gs2,nframes2,exct2]=lpc_analysis(y2,1,length(y2),L_index,R_index,p);
[p1m2,pitch2]=gen_pitch(y2,fs_new,L_index,R_index,nframes2);
As2(:,3:15) = As_aw(:,60:72);
Gs2(3:15) = Gs_aw(60:72);
[e4]=create_excitation_signal(nframes2,R_index,pitch2);
[s4]=synthesize_speech(1,length(y2),L_index,R_index,nframes2,1,e4,Gs2,As2,p,0,hamming(L_index)');

figure;
h = pcolor(As2);
set(h, 'EdgeColor', 'none');
audiowrite('C:\Users\ADM�N\Desktop\dsp\proje\lpc_vocoder\dnm3.wav',[s2;s3;s4],fs_new);
%[f0_time,f0_value,SHR,f0_candidates]=shrp(y,fs_new);
%plot(y)
% eee1=create_excitation(pitch1,R_index);
% eee2=create_excitation(pitch2,R_index);
% 
% % figure;
% % plot(eee1);
% %hold on;
% %plot(eee2);

%[ex,exn,Gain] = normalize_excitation(e,R_index,Gs);
%% write audio file
audiowrite('C:\Users\ADM�N\Desktop\dsp\proje\lpc_vocoder\dnm.wav',s2,fs_new);
%%
audiowrite('C:\Users\ADM�N\Desktop\dsp\proje\lpc_vocoder\dnm2.wav',s2,fs_new);
% [s3]=synthesize_speech(1,length(y2),L_index,R_index,nframes2,1,e1,Gs2,As2,p,0,hamming(L_index)');
% audiowrite('C:\Users\ADM�N\Desktop\dsp\proje\lpc_vocoder\dnm.wav',s3,fs_new);
% figure;
% plot(s);