function [new_accent,original_after_LPC,fs_new]=accent_change(time_interval,samples,fs,As_acc,Gs_acc,center)
filtered = highpass_filter(samples(:,1),fs);%samples might be 2D, ex. mp3 files
fs_new = 8000;
y = resample(filtered,fs_new,fs);%downsample to 8kHZ
%initialize LPC
L = 40;%ms frame size
R=10; %ms frame shift
L_index = round(L/1000*fs_new) ;
R_index = round(R/1000*fs_new) ;
p = 200;%LPC order
[As,Gs,nframes,exct]=lpc_analysis(y,1,length(y),L_index,R_index,p);
%save original coefficeints
As_o = As;
Gs_o = Gs;
%change coefficients
if isempty(time_interval) == 0 %does not change accent
time_interval = time_interval*1000;%s to ms
for k = 1:length(time_interval)
    display(k)
    cut = (time_interval(2,k) - time_interval(1,k))/5;
    start = floor((time_interval(1,k)+cut-L)/R+1);
    stop = floor((time_interval(2,k)-cut-L)/R+1);
    duration = stop-start;
    left = center - ceil(duration/2);
    right = center + floor(duration/2);
    As(:,start:stop) = As_acc(:,left:right);
    Gs(start:stop) = Gs_acc(left:right);
end
end
%%pitch generation
[p1m,pitch]=gen_pitch(y,fs_new,L_index,R_index,nframes);
%[f0_time,f0_value,SHR,f0_candidates]=shrp(y,fs_new);
%plot(y)
% eee=create_excitation(pitch,R_index);
% 
% figure;
% plot(eee);
[e]=create_excitation_signal(nframes,R_index,pitch);
%[ex,exn,Gain] = normalize_excitation(e,R_index,Gs);
[original_after_LPC]=synthesize_speech(1,length(y),L_index,R_index,nframes,1,e,Gs_o,As_o,p,0,hamming(L_index)');
[new_accent]=synthesize_speech(1,length(y),L_index,R_index,nframes,1,e,Gs_o,As,p,0,hamming(L_index)');
end