function [As_new,Gs_new]=co_change(time_interval,As,Gs,As_acc,Gs_acc,center)
%change coefficients
L = 40;%ms frame size
R=10; %ms frame shift
As_new = As;
Gs_new = Gs;
if isempty(time_interval) == 0 %does not change accent
time_interval = time_interval*1000;%s to ms
for k = 1:length(time_interval)
    display(k)
    cut = (time_interval(2,k) - time_interval(1,k))/5;
    start = floor((time_interval(1,k)+cut-L)/R+1);
    stop = floor((time_interval(2,k)-cut-L)/R+1);
    duration = stop-start;
    left = center - ceil(duration/2);
    right = center + floor(duration/2);
    As_new(:,start:stop) = As_acc(:,left:right);
    Gs_new(start:stop) = Gs_acc(left:right);
end
end
end