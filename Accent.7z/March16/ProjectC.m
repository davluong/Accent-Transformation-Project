function varargout = ProjectC(varargin)
% PROJECTC MATLAB code for ProjectC.fig
%      PROJECTC, by itself, creates a new PROJECTC or raises the existing
%      singleton*.
%
%      H = PROJECTC returns the handle to a new PROJECTC or the handle to
%      the existing singleton*.
%
%      PROJECTC('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PROJECTC.M with the given input arguments.
%
%      PROJECTC('Property','Value',...) creates a new PROJECTC or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ProjectC_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ProjectC_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ProjectC

% Last Modified by GUIDE v2.5 15-Mar-2019 15:50:47

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ProjectC_OpeningFcn, ...
                   'gui_OutputFcn',  @ProjectC_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);

if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ProjectC is made visible.
function ProjectC_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ProjectC (see VARARGIN)

% Choose default command line output for ProjectC
handles.output = hObject;
handles.file='guitest.wav';
handles.tpeakur=[];
handles.tpeakaa=[];
handles.tpeakee=[];
handles.tpeaka=[];
handles.tpeakih=[];
handles.tperiodur=[];
handles.tperiodaa=[];
handles.tperiodee=[];
handles.tperioda=[];
handles.tperiodih=[];
handles.examplefile=[];
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes ProjectC wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = ProjectC_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in Record.
function Record_Callback(hObject, eventdata, handles)
% hObject    handle to Record (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[myRecording,fs]=guirecord();
plot(linspace(0,length(myRecording)/fs,length(myRecording)),myRecording)

% --- Executes on button press in ur.
function ur_Callback(hObject, eventdata, handles)
% hObject    handle to ur (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
file2=handles.file;
[t,p,T,test,pks,loc,coe,t1]=urpack(file2);
tp=linspace(0,T,length(p));
pks=log10(pks);
[spk,I]=sort(pks,'descend');
sloc=loc(I);
plot(tp,log10(p))
xlabel('time(s)')
ylabel('Probility density Log10 scale')
title('Probility density of the phoneme vs time')
ylim([-15,2])
xlim([0,10])
for i=1:length(pks)
    text(sloc(i),spk(i),num2str(i))
end
pp=str2num(get(handles.ur_ind,'string'));
hold on
scatter(sloc(pp),spk(pp))
hold off
%set(handles.tpeakur,'string',sloc(pp));
handles.tpeakur=sloc(pp)
t=phse(coe,t1,sloc(pp));
handles.tperiodur=t;
t
guidata(hObject,handles);
handles
pp;

% --- Executes on button press in ih.
function ih_Callback(hObject, eventdata, handles)
% hObject    handle to ih (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
file2=handles.file;
[t,p,T,test,pks,loc,coe,t1]=ihpack(file2);
tp=linspace(0,T,length(p));
pks=log10(pks);
[spk,I]=sort(pks,'descend');
sloc=loc(I);
plot(tp,log10(p))
xlabel('time(s)')
ylabel('Probility density Log10 scale')
title('Probility density of the phoneme vs time')
ylim([-15,2])
xlim([0,10])
for i=1:length(pks)
    text(sloc(i),spk(i),num2str(i))
end
pp=str2num(get(handles.ih_ind,'string'));
hold on
scatter(sloc(pp),spk(pp))
hold off
%set(handles.tpeakur,'string',sloc(pp));
handles.tpeakih=sloc(pp);
t=phse(coe,t1,sloc(pp));
handles.tperiodih=t;
t
guidata(hObject,handles);
handles
pp;


% --- Executes on button press in aa.
function aa_Callback(hObject, eventdata, handles)
% hObject    handle to aa (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
file2=handles.file;
[t,p,T,test,pks,loc,coe,t1]=aapack(file2);
tp=linspace(0,T,length(p));
pks=log10(pks);
[spk,I]=sort(pks,'descend');
sloc=loc(I);
plot(tp,log10(p))
xlabel('time(s)')
ylabel('Probability density Log10 scale')
title('Probability density of the phoneme vs time')
ylim([-15,2])
xlim([0,10])
for i=1:length(pks)
    text(sloc(i),spk(i),num2str(i))
end
pp=str2num(get(handles.aa_ind,'string'));
hold on
scatter(sloc(pp),spk(pp))
hold off
%set(handles.tpeakur,'string',sloc(pp));
handles.tpeakaa=sloc(pp);
t=phse(coe,t1,sloc(pp));
handles.tperiodaa=t;
t
guidata(hObject,handles);
handles
pp;

% --- Executes on button press in a.
function a_Callback(hObject, eventdata, handles)
% hObject    handle to a (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
file2=handles.file
[t,p,T,test,pks,loc,coe,t1]=apack(file2);
tp=linspace(0,T,length(p));
pks=log10(pks);
[spk,I]=sort(pks,'descend');
sloc=loc(I);
plot(tp,log10(p))
xlabel('time(s)')
ylabel('Probability density Log10 scale')
title('Probability density of the phoneme vs time')
ylim([-15,2])
xlim([0,10])
for i=1:length(pks)
    text(sloc(i),spk(i),num2str(i))
end
pp=str2num(get(handles.a_ind,'string'));
hold on
scatter(sloc(pp),spk(pp))
hold off
%set(handles.tpeakur,'string',sloc(pp));
handles.tpeaka=sloc(pp);
t=phse(coe,t1,sloc(pp));
handles.tperioda=t;
t
guidata(hObject,handles);
handles
pp;


% --- Executes on button press in ee.
function ee_Callback(hObject, eventdata, handles)
% hObject    handle to ee (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
file2=handles.file
[t,p,T,test,pks,loc,coe,t1]=eepack(file2);
tp=linspace(0,T,length(p));
pks=log10(pks);
[spk,I]=sort(pks,'descend');
sloc=loc(I);
plot(tp,log10(p))
xlabel('time(s)')
ylabel('Probability density Log10 scale')
title('Probability density of the phoneme vs time')
ylim([-15,2])
xlim([0,10])
for i=1:length(pks)
    text(sloc(i),spk(i),num2str(i))
end
pp=str2num(get(handles.ee_ind,'string'));
hold on
scatter(sloc(pp),spk(pp))
hold off
%set(handles.tpeakur,'string',sloc(pp));
handles.tpeakee=sloc(pp);
t=phse(coe,t1,sloc(pp));
handles.tperiodee=t;
t
guidata(hObject,handles);
handles
pp;


% --- Executes on button press in Record.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to Record (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function ur_ind_Callback(hObject, eventdata, handles)
% hObject    handle to ur_ind (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ur_ind as text
%        str2double(get(hObject,'String')) returns contents of ur_ind as a double
pickpeaks=get(hObject,'String');
display(pickpeaks)

% --- Executes during object creation, after setting all properties.
function ur_ind_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ur_ind (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Clearrecognition.
function Clearrecognition_Callback(hObject, eventdata, handles)
% hObject    handle to Clearrecognition (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.tpeakur=[];
handles.tpeakaa=[];
handles.tpeakee=[];
handles.tpeaka=[];
handles.tpeakih=[];
handles.tperiodur=[];
handles.tperiodaa=[];
handles.tperiodee=[];
handles.tperioda=[];
handles.tperiodih=[];
handles.examplefile=[];
handles
guidata(hObject,handles);



function ih_ind_Callback(hObject, eventdata, handles)
% hObject    handle to ih_ind (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ih_ind as text
%        str2double(get(hObject,'String')) returns contents of ih_ind as a double


% --- Executes during object creation, after setting all properties.
function ih_ind_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ih_ind (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function aa_ind_Callback(hObject, eventdata, handles)
% hObject    handle to aa_ind (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of aa_ind as text
%        str2double(get(hObject,'String')) returns contents of aa_ind as a double


% --- Executes during object creation, after setting all properties.
function aa_ind_CreateFcn(hObject, eventdata, handles)
% hObject    handle to aa_ind (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function a_ind_Callback(hObject, eventdata, handles)
% hObject    handle to a_ind (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of a_ind as text
%        str2double(get(hObject,'String')) returns contents of a_ind as a double


% --- Executes during object creation, after setting all properties.
function a_ind_CreateFcn(hObject, eventdata, handles)
% hObject    handle to a_ind (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ee_ind_Callback(hObject, eventdata, handles)
% hObject    handle to ee_ind (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ee_ind as text
%        str2double(get(hObject,'String')) returns contents of ee_ind as a double


% --- Executes during object creation, after setting all properties.
function ee_ind_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ee_ind (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Userecord.
function Userecord_Callback(hObject, eventdata, handles)
% hObject    handle to Userecord (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.file='guitest.wav';
handles
guidata(hObject,handles);

% --- Executes on button press in Batman.
function Batman_Callback(hObject, eventdata, handles)
% hObject    handle to Batman (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.file='Batman.wav';

% --- Executes on button press in radiobutton1.
function radiobutton1_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton1


% --- Executes on button press in checkbox2.
function checkbox2_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox2


% --- Executes on selection change in examples.
function examples_Callback(hObject, eventdata, handles)
% hObject    handle to examples (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns examples contents as cell array
%        contents{get(hObject,'Value')} returns selected item from examples
a=get(handles.examples,'Value')
if a==1
    handles.examplefile='Batman.wav';
elseif a==2
    handles.examplefile='ur_sentence.wav';
elseif a==3
    handles.examplefile='ih_sentence.wav';
elseif a==4
    handles.examplefile='teacheese.wav';
end
guidata(hObject,handles);
disp(handles.examplefile)
disp('example file')
% --- Executes during object creation, after setting all properties.
function examples_CreateFcn(hObject, eventdata, handles)
% hObject    handle to examples (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in useexample.
function useexample_Callback(hObject, eventdata, handles)
% hObject    handle to useexample (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.file=handles.examplefile;
guidata(hObject,handles);
handles

% --- Executes on button press in playfile.
function playfile_Callback(hObject, eventdata, handles)
% hObject    handle to playfile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
filename=handles.file;
filename
[y, Fs] = audioread(filename);
t=linspace(0,length(y)/Fs,length(y));
figure
plot(t,y)
xlabel('time(s)')
title('Time sequence of the current wav file')


% --- Executes during object creation, after setting all properties.
function playfile_CreateFcn(hObject, eventdata, handles)
% hObject    handle to playfile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on button press in writedata.
function writedata_Callback(hObject, eventdata, handles)
% hObject    handle to writedata (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
tur=handles.tperiodur;
taa=handles.tperiodaa;
tee=handles.tperiodee;
ta=handles.tperioda;
tih=handles.tperiodih;
csvwrite('t_ur',tur)
csvwrite('t_aa',taa)
csvwrite('t_ee',tee)
csvwrite('t_a',ta)
csvwrite('t_ih',tih)
