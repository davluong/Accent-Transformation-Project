%function LPC(accent,file)
%clear all;
%initialize
%fs_new = 8000;
% L = 40;%ms frame size
% R=10; %ms frame overlap
% L_index = round(L/1000*fs_new) ;
% R_index = round(R/1000*fs_new) ;
% p = 200;
clear
accent=0;%%% 0 british, 1 southern, 2 midwestern
%file='Batman.wav';%Batman.wav, guitest.wav
file='guitest.wav';
t1=importdata('t_aa');
t2=importdata('t_a');
t3=importdata('t_ih');
t4=importdata('t_ur');
t5=importdata('t_ee');
% t_aa = [2.5904    3.6345    7.6104    8.2129;...
%      2.8112    3.8956    7.9116    8.4538];
t_aa=t1;
t_ee=t5;
t_ah=t2;
t_ih=t3;
t_ur=t4;
refile1=['re_',file];
refile2=['re','_accent_',file];
% [yraw,fs] = audioread('Batman.wav');
% y = resample(yraw,fs_new,fs);
%[s_out,As,Gs] = lpc_out(L_index,R_index,p,'Batman.wav',fs_new);
%%
% [s,fs] = audioread('Batman.wav');
% [new_accent,original_after_LPC]=accent_change(t,s,fs,As_ah,Gs_ah,75);
% audiowrite('C:\Users\ADM�N\Desktop\dsp\proje\reBatman.wav',original_after_LPC,fs_new);
% audiowrite('C:\Users\ADM�N\Desktop\dsp\proje\reBatman2.wav',new_accent,fs_new);
%%
[new_accent,original_after_LPC,fs_new] = ...
    main(file,accent,t_aa,t_ee,t_ah,t_ih,t_ur);
audiowrite(refile1,original_after_LPC,fs_new);
audiowrite(refile2,new_accent,fs_new);