function [myRecording,Fs]=guirecord()
Fs=16000;       
nBits=8;
nChannels=1;
recObj = audiorecorder(Fs,nBits,nChannels);
disp('Recording begin, 10 seconds')
recordblocking(recObj, 10);
%play(recObj);
myRecording = getaudiodata(recObj);
audiowrite('guitest.wav',myRecording,Fs);
disp('record complete, data saved to guitest.wav')
end