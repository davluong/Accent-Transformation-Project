function t=phse(coe,T,loc)
%Calculate the timeperiod of the target phoneme
A=(coe>=-1.5);
[ts,te]=se(A,T);
    function [ts,te]=se(A,T)
        l=length(A);
        ts=[];
        te=[];
        for i=2:l
            if A(i-1)==0 && A(i)==1
                ts=[ts,T(i)];
            else if A(i-1)==1 && A(i)==0
                    te=[te,T(i)];
                end
            end
        end
    end
l=length(ts);
l1=length(loc);
ts1=[];
te1=[];
for i=1:l
    for j=1:l1
        if loc(j) <= te(i) && loc(j) >=ts(i)
            ts1=[ts1,ts(i)];
            te1=[te1,te(i)];
        end
    end
end
t=[ts1;te1];
end
