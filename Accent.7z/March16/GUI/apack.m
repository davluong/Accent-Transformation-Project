function [t,p,T,test,pks,loc,coe,t1]=apack(file2)
file1='bo.wav';
M=train(file1);% train the model with the data from file1
[p,test,fs,tcoe1]=recph(M,file2); % Use the model the predict the appearance of the phoneme in file2.
thrh=10^-15;
[pks,loc]=mkphn(p,test,fs,thrh);
coe=tcoe1(:,1);
t1=linspace(0,length(test)/fs,length(coe));
T=length(test)/fs;
t=phse(coe,t1,loc);

function M=train(file)
% This function imports a wav 'file' as database to build a model 'M'.
% The model 'M' is used for phoneme recognition. 

% import data from file
[data,fs]=audioread(file); 
s=size(data,1);
T=s/fs;

%Preprocess the wav file data by filter the data with a bandpass filter
c1=300; % Low cutoff frequency, Hz
c2=7000; % Upper cutoff frequency, Hz
[b,a] = butter(4,[2*c1/fs,2*c2/fs],'bandpass');
data=filter(b,a,data);

%characterize the data with MFCC
[coeffs,delta,deltaDelta,loc] = mfcc(data,fs,'WindowLength',round(fs*0.04),'OverLapLength',round(fs*0.02)); % Generate MFCC coefficients once every 100ms
coe=deb(coeffs); %Delete the silence between sounds
coe1=coe;
coe=sortsp(coe); %Sort the MFCC coefficents
size(coe)
coe=coe(1:300,:); % Just take one part of the coefficients as database1
coe=coe(:,2:13); % Each frame has 14 MFCC coefficients, delete the first row and save the rest.

%Train the model with the database
M=fitgmdist(coe,1);

%Plot the MFCC database that corresponds to the sound.
t=linspace(0,T,size(coe,1));
y=1:12;
% figure
%contourf(t,y,coe')
% contourf(coe')
% colorbar()
% caxis([-16 1])
% xlabel('time(s)')
% ylabel('MFCC Coefficients')
% title(['MFCC database of sound','  ',file])
end

function coe0=deb(coe)
s=size(coe,1);
coe0=[];
for i=1:s
    lmt=-20;
    if coe(i,1)>=lmt
        coe0=[coe0;coe(i,:)];
    end
end
end

function y=sortsp(x)
s=sum(x,2);
[B,I]=sort(s,'descend');
y=x(I,:);
end
function [pks1,loc1]=mkphn(p,test,fs,thrh)%mark phoneme on the time sequence
l=length(test);
T=l/fs;
tp=linspace(0,T,length(p));
[pks,loc]=findpeaks(p,tp,'MinPeakDistance',0.4); % search the phoneme every 0.2 seconds
% figure
% scatter(loc,pks)
%thrh=10^-5;
[pks1,loc1]=pkpn(pks,loc,thrh);
pks2=pks1*0;
tw=linspace(0,T,length(test));
% figure
% plot(tw,test)
% xlabel('time(s)')
% title('Time sequence of the test wav file marked with target phoneme')
% hold on
% scatter(loc1,pks2)
% hold off

function [pks1,loc1]=pkpn(pks,loc,thrh)
loc1=[];
pks1=[];
l=length(loc);
for i=1:l
    if pks(i)>=thrh
        loc1=[loc1,loc(i)];
        pks1=[pks1,pks(i)];
    end
end
end
end

function t=phse(coe,T,loc)
%Calculate the timeperiod of the target phoneme
A=(coe>=-1.5);
[ts,te]=se(A,T);
    function [ts,te]=se(A,T)
        l=length(A);
        ts=[];
        te=[];
        for i=2:l
            if A(i-1)==0 && A(i)==1
                ts=[ts,T(i)];
            else if A(i-1)==1 && A(i)==0
                    te=[te,T(i)];
                end
            end
        end
    end
l=length(ts);
l1=length(loc);
ts1=[];
te1=[];
for i=1:l
    for j=1:l1
        if loc(j) <= te(i) && loc(j) >=ts(i)
            ts1=[ts1,ts(i)];
            te1=[te1,te(i)];
        end
    end
end
t=[ts1;te1];
end

function [p,test,fs,tcoe1]=recph(M,file)%recognize phonemes
%This function calculates the probability of the phonemes appears at
%certain time in a test sentence(Recorded in 'file')

%Read the data from file and plot it in time domain
[test,fs]=audioread(file);
s=size(test,1);
t=linspace(0,s/fs,s);
% figure
% plot(t,test)
% xlabel('time(s)')
% title(['time sequence of ',' ',file])

%preprocess the test data with the same bandpass filter
c1=300;
c2=7000;
[b,a] = butter(4,[2*c1/fs,2*c2/fs],'bandpass');
test=filter(b,a,test);

%Obtain the MFCC coefficients of the test file and plot them
[coeffs,delta,deltaDelta,loc] = mfcc(test,fs,'WindowLength',round(fs*0.04),'OverLapLength',round(fs*0.02));
tcoe=coeffs;
tc=cs(tcoe);%Mark the silence part of the sentence
tcoe1=tcoe;
tcoe=tcoe(:,2:13);%Only the 2nd to the 13th of the MFCC coefficients are useful
t=linspace(0,s/fs,size(tcoe,1));
y=1:12;
% figure
% contourf(t,y,tcoe')
% xlabel('time(s)')
% title(['MFCC spectrogram of ',file])

%Predict the probility of the phoneme appearing at each time point
p=pdf(M,tcoe);
t=linspace(0,s/fs,size(p,1));
p(isnan(p))=0;
p=tc.*p;
% figure
% plot(t,log10(p))
% xlabel('time(s)')
% ylabel('log10(Probility)')
% title(['Probility of the appearance of the phoneme at t(s)'])
end

function y=cs(x)
s=size(x,1);
y=zeros(s,1);
for i=1:s
    lmt=-20;
    if x(i,1)>=lmt
        y(i)=1;
    end
end
end
end