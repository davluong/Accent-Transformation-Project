clear
letter='hhh';
p=0;
S=[];
for i=1:1
    file=['phonemes/',letter,num2str(i),'.wav'];
    [coe,fe]=MFCCwav(file,p);
    ind=ls(fe);
    coe1=coe(:,ind);
    S=[S,coe1];
end
figure
contourf(S)
ad=['phonemes/',letter]
csvwrite(ad,S)

function ind=ls(M)%locate the sound
s=sum(M);
ma=max(s);
mi=min(s);
N=length(s);
ind=[];
for i=1:N
    if s(i)>=0.1*ma
        ind=[ind,i];
    end
end
end