function d=nor(M)
l=size(M);
l=l(2);
for i=1:l
    [s,n]=sumsqr(M(:,i));
    ma=(s/n)^0.5;
    if ma==0
        M(:,i)=M(:,i);
    else
        M(:,i)=M(:,i)/ma;
    end
end
d=M;
end