%train
clear
[name,num]=readdir('phonemes')
% l=length(name);
% label=[];
% data=[];
% for i=1:3
%     name(i)
%     [d,l1]=readdata(name(i),num(i));
%     %label=[label,i*ones(1,l1)];
%     label=[label,i*ones(1,300)];
%     data=[data,d(:,1:300)];
% end
% figure
% contourf(data)
% colorbar
% 
% [z1,model,llh] = mixGaussEm(data,label);

function [d,l]=readdata(name,num)
name=char(name);
S=[];
F=[];
for i=1:num
    file=['phonemes/',name,num2str(i),'.wav'];
    [coe,fe]=MFCCwav(file,0);
    ind=ls(fe);
    coe1=coe(:,ind);
    fe1=fe(:,ind);
    S=[S,coe1];
    F=[F,fe1];
end
d=nor(S(2:13,:));
%include filterbank
fe=nor(F);
%d=[d;fe];
l=size(d);
l=l(2);
end

function ind=ls(M)%locate the sound
s=sum(M);
ma=max(s);
mi=min(s);
N=length(s);
ind=[];
for i=1:N
    if s(i)>=0.1*ma
        ind=[ind,i];
    end
end
end
