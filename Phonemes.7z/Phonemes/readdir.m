function [na0,num]=readdir(folder)
% folder is the folder path
% na0 is the list of phonemes
% num is the corresponding samples of each phoneme
fi=dir(folder);% folder information
name={fi.name};
name=name(~strncmp(name, '.', 1));
l=length(name);
na=string([]);
for i=1:l
    na1=name(i);
    na1=char(na1);
    na3=[];
    for j=1:3
        na2=na1(j);
        if isletter(na2)==1
            na3=[na3,na2];
        else
            break;
        end
    end
    na3;
    na(i)=string(na3);
end
nas=sort(na);
l=length(nas);
na0=string([]);
n=[];
nu=1;
j=0;
for i=1:l
    if i==1
        j=j+1;
        na0(j)=nas(i);
        num(j)=nu;
    else
        if nas(i)==nas(i-1)
            nu=nu+1;
            num(j)=nu;
            na0(j)=nas(i);
        else
            j=j+1;
            nu=1;
            num(j)=nu;
            na0(j)=nas(i);
        end
    end
end
end