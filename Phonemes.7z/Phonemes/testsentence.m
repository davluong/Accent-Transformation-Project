%the model must have been trained using 'trainall'
[b,a]=butter(6,[0.05,0.4],'bandpass');
Fs=8000;
nBits=8;
nChannels=1;
file='database/test.wav';
jd=input('startrecording? press y    ','s');
if jd=='y'
recObj = audiorecorder(Fs,nBits,nChannels);
recordblocking(recObj, 20);
disp('End of Recording.');
play(recObj);
myRecording = getaudiodata(recObj);
myRecording1=filter(b,a,myRecording);
plot(myRecording1)
end
jd=input('do you want it?,press y if you want it       ','s');
if jd=='y'
audiowrite(file,myRecording,Fs);
else
    disp('use the test.wav in the folder')
end
jd=input('Analyse it?,press y if you want       ','s');
if jd=='y'
[coe,fe]=MFCCwav(file,1);
coe=coe(2:13,:);
coe=nor(coe);
figure
contourf(coe)
colorbar
[plab,R]= mixGaussPred(coe,model);
disp('end of the program, data is in plab and R')
figure
t=(1:length(plab));
scatter(t,plab.*delb(fe))
xlabel('time(s)')
else
disp('end of the program')
end

function y=delb(x)%delete blank
ma=max(sum(x));
l=size(x);
y=x(1,:)*0;
for i=1:l(2)
    if sum(x(:,i))<=0.05*ma
        y(i)=0;
    else
        y(i)=1;
    end
end
end
