%train
clear
b=importdata('b');
d=importdata('d');
g=importdata('g');
h=importdata('h');
n=200;
data=[b(:,1:n),d(:,1:n),g(:,1:n)];
label=[ones(1,n),ones(1,n)*2,ones(1,n)*3];
test=[b(:,(n+1):end),d(:,(n+1):end),g(:,(n+1):end)];
tlab=[ones(1,length(b(:,(n+1):end))),2*ones(1,length(d(:,(n+1):end))),3*ones(1,length(g(:,(n+1):end)))];
[z1,model,llh] = mixGaussEm(data,label);
[plab,R]= mixGaussPred(test,model);
figure
plot(tlab)
hold on
plot(plab)
hold off