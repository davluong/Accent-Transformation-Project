clear
[name,num]=readdir('phonemes');
i=30;
[d,l]=readdata(name(i),num(i));
csvwrite('database/name',name)
csvwrite('database/num',l) % num of samples
csvwrite('database/data',d) % MFCC of the phonemes


function [d,l]=readdata(name,num)
name=char(name);
S=[];
for i=1:num
    file=['phonemes/',name,num2str(i),'.wav'];
    [coe,fe]=MFCCwav(file,0);
    ind=ls(fe);
    coe1=coe(:,ind);
    S=[S,coe1];
end
d=S(2:13,:);
l=size(d);
l=l(1);
%figure
%contourf(d)
%title(name)
end

function ind=ls(M)%locate the sound
s=sum(M);
ma=max(s);
mi=min(s);
N=length(s);
ind=[];
for i=1:N
    if s(i)>=0.1*ma
        ind=[ind,i];
    end
end
end