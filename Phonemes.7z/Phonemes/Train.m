%train
clear
b=importdata('b');
d=importdata('d');
g=importdata('g');

tod=0.8;
nb=length(b);nb1=floor(tod*nb);
nd=length(d);nd1=floor(tod*nd);
ng=length(g);ng1=floor(tod*ng);

data=[b(:,1:nb1),d(:,1:nd1),g(:,1:ng1)];
label=[ones(1,nb1),ones(1,nd1)*2,ones(1,ng1)*3];
test=[b(:,(nb1+1):nb),d(:,(nd1+1):nd),g(:,(ng1+1):ng)];
tlab=[ones(1,nb-nb1),2*ones(1,nd-nd1),3*ones(1,ng-ng1)];
[z1,model,llh] = mixGaussEm(data,label);
[plab,R]= mixGaussPred(test,model);
figure
plot(tlab)
hold on
plot(plab)
hold off