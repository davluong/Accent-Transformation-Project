function [new_accent,original_after_LPC]=accent_change(time_interval,samples,which_accent,fs)
filtered = highpass_filter(samples(:,1),fs);%samples might be 2D, ex. mp3 files
fs_new = 8000;
y = resample(filtered,fs_new,fs);%downsample to 8kHZ
%initialize LPC
L = 40;%ms frame size
R=10; %ms frame shift
L_index = round(L/1000*fs_new) ;
R_index = round(R/1000*fs_new) ;
p = 20;%LPC order
[As,Gs,nframes,exct]=lpc_analysis(y,1,length(y),L_index,R_index,p);
%save original coefficeints
As_o = As;
Gs_o = Gs;
%change coefficients
start = floor((time_interval(1)-L)/R+1);
stop = floor((time_interval(2)-L)/R+1);
As(:,start:stop) = 
Gs(start:stop) = 
%%pitch generation
[p1m,pitch]=gen_pitch(y,fs_new,L_index,R_index,nframes);
%[f0_time,f0_value,SHR,f0_candidates]=shrp(y,fs_new);
%plot(y)
% eee=create_excitation(pitch,R_index);
% 
% figure;
% plot(eee);
[e]=create_excitation_signal(nframes,R_index,pitch);
%[ex,exn,Gain] = normalize_excitation(e,R_index,Gs);
[original_after_LPC]=synthesize_speech(1,length(y),L_index,R_index,nframes,1,e,Gs_o,As_o,p,0,hamming(L_index)');
[s1]=synthesize_speech(1,length(y1),L_index,R_index,nframes,1,e1,Gs_r,As_r,p,0,hamming(L_index)');
end