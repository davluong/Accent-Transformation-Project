function M=train(file)
% This function imports a wav 'file' as database to build a model 'M'.
% The model 'M' is used for phoneme recognition. 

% import data from file
[data,fs]=audioread(file); 
s=size(data,1);
T=s/fs;

%Preprocess the wav file data by filter the data with a bandpass filter
c1=300; % Low cutoff frequency, Hz
c2=7000; % Upper cutoff frequency, Hz
[b,a] = butter(4,[2*c1/fs,2*c2/fs],'bandpass');
data=filter(b,a,data);

%characterize the data with MFCC
[coeffs,delta,deltaDelta,loc] = mfcc(data,fs,'WindowLength',round(fs*0.05),'OverLapLength',round(fs*0.03)); % Generate MFCC coefficients once every 100ms
coe=deb(coeffs); %Delete the silence between sounds
coe1=coe;
coe=sortsp(coe); %Sort the MFCC coefficents
size(coe)
coe=coe(1:300,:); % Just take one part of the coefficients as database1
coe=coe(:,2:13); % Each frame has 14 MFCC coefficients, delete the first row and save the rest.

%Train the model with the database
M=fitgmdist(coe,1);

%Plot the MFCC database that corresponds to the sound.
figure
t=linspace(0,T,size(coe,1));
y=1:12;
%contourf(t,y,coe')
contourf(coe')
colorbar()
caxis([-16 1])
xlabel('time(s)')
ylabel('MFCC Coefficients')
title(['MFCC database of sound','  ',file])
end