function y=cs(x)
s=size(x,1);
y=zeros(s,1);
for i=1:s
    lmt=-20;
    if x(i,1)>=lmt
        y(i)=1;
    end
end
end