%recorddata
clear
% Record your voice for 5 seconds.
Fs=16000;       
nBits=8;
nChannels=1;
i=1;
while i<=1000
recObj = audiorecorder(Fs,nBits,nChannels);
%disp('Start speaking.')
st=input('startrecording? press any key');
recordblocking(recObj, 10);
disp('End of Recording.');
play(recObj);
myRecording = getaudiodata(recObj);
plot(myRecording)
jd1=input('Record it? y for yes, others for no      ','s');
if jd1=='y'
    filename=input('filename, no extension     ','s');
    %filename='test';
    file=[filename,'.wav'];
    audiowrite(file,myRecording,Fs);
end
jd2=input('Next one? n for no, others for yes   ','s');
if jd2=='n'
    i=10000;
    disp('stop')
end
end
