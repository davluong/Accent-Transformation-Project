function coe0=deb(coe)
s=size(coe,1);
coe0=[];
for i=1:s
    lmt=-20;
    if coe(i,1)>=lmt
        coe0=[coe0;coe(i,:)];
    end
end
end