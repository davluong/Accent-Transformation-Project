clear
file1='ur_her.wav';
M=train(file1);% train the model with the data from file1
file2='ur_sentence.wav';
p=recph(M,file2); % Use the model the predict the appearance of the phoneme in file2.

