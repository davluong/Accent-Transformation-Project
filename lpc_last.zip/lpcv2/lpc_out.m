function [s_out,As,Gs] = lpc_out(L_index,R_index,p,name,fs_new)
    [yraw,fs] = audioread(name);
    y_filtered = highpass_filter(yraw(:,1),fs);
    y = resample(y_filtered,fs_new,fs);%downsample to 8kHZ
    [As,Gs,nframes,exct]=lpc_analysis(y,1,length(y),L_index,R_index,p);
    [p1m,pitch]=gen_pitch(y,fs_new,L_index,R_index,nframes);
    [e]=create_excitation_signal(nframes,R_index,pitch);
    [s_out]=synthesize_speech(1,length(y),L_index,R_index,nframes,1,e,Gs,As,p,0,hamming(L_index)');
end