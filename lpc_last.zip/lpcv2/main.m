function [new_accent,original_after_LPC,fs_new] = ...
    main(filename_original,accent,t_aa,t_ee,t_ah,t_ih,t_ur)
%%% 0 british, 1 southern, 2 midwestern
%clear all;
%initialize
fs_new = 8000;
L = 40;%ms frame size
R=10; %ms frame overlap
L_index = round(L/1000*fs_new) ;
R_index = round(R/1000*fs_new) ;
p = 200;
%library
%[s_out_aa,As_aa,Gs_aa] = lpc_out(L_index,R_index,p,'aa.wav',fs_new);
[s_out_ah,As_ah,Gs_ah] = lpc_out(L_index,R_index,p,'ah.wav',fs_new);
%[s_out_ur,As_ur,Gs_ur] = lpc_out(L_index,R_index,p,'ur.wav',fs_new);
[s_out_aw,As_aw,Gs_aw] = lpc_out(L_index,R_index,p,'aw.wav',fs_new);
%[s_out_uh,As_uh,Gs_uh] = lpc_out(L_index,R_index,p,'uh.wav',fs_new);
[s_out_ehg,As_ehg,Gs_ehg] = lpc_out(L_index,R_index,p,'ehg.wav',fs_new);
%[s_out_ee,As_ee,Gs_ee] = lpc_out(L_index,R_index,p,'ee.wav',fs_new);
%[s_out_ih,As_ih,Gs_ih] = lpc_out(L_index,R_index,p,'ih.wav',fs_new);
%database for domnant vowels
[s,fs] = audioread(filename_original);%rawdata
filtered = highpass_filter(s(:,1),fs);%samples might be 2D, ex. mp3 files
y = resample(filtered,fs_new,fs);%downsample to 8kHZ
[As,Gs,nframes,exct]=lpc_analysis(y,1,length(y),L_index,R_index,p);
%save original coefficeints
As_o = As;
Gs_o = Gs;
center_ah = 75;
center_aw = 75;
center_ehg = 58;
%change coefficients
switch accent
    case 0
        %british, map from aa,ah to ah,aw
        [As_new,Gs_new]= co_change(t_aa,As,Gs,As_ah,Gs_ah,center_ah);
        [As_new,Gs_new]= co_change(t_ah,As_new,Gs_new,As_aw,Gs_aw,center_aw);
    case 1
        %southern, map from ee,ih to ehg
        [As_new,Gs_new]= co_change(t_ee,As,Gs,As_ehg,Gs_ehg,center_ehg);
        [As_new,Gs_new]= co_change(t_ih,As_new,Gs_new,As_ehg,Gs_ehg,center_ehg);
    case 2
        %midwestern, map from aa,ur to eh,ehg
        [As_new,Gs_new]= co_change(t_aa,As,Gs,As_ah,Gs_ah,center_ah);
        [As_new,Gs_new]= co_change(t_ur,As_new,Gs_new,As_ehg,Gs_ehg,center_ehg);
end
[p1m,pitch]=gen_pitch(y,fs_new,L_index,R_index,nframes);
[e]=create_excitation_signal(nframes,R_index,pitch);
[original_after_LPC]=synthesize_speech(1,length(y),L_index,R_index,nframes,1,e,Gs_o,As_o,p,0,hamming(L_index)');
[new_accent]=synthesize_speech(1,length(y),L_index,R_index,nframes,1,e,Gs_o,As_new,p,0,hamming(L_index)');
end