clear
w0=[1 10];
%w1=[0.1 1];
f0=[0 0.3 0.394 1];
a0=[1 1 0 0];
n=51;
b = remez(n,f0,a0,w0);
%b1 = remez(n,f0,a0,w1);
[h,w]=freqz(b);
%[h1,w1]=freqz(b1);
plot(w,(abs(h)))
hold on
%plot(w1,(abs(h1)))
hold off
xlabel('frequency(pi)')
ylabel('|H|(dB)')
title('Frequency response')
%legend('Kp/Ks=0.1','Kp/Ks=10')

function d=dB(x)
d=20*log10(x);
end
