clear
w0=[1 10];
fa=[0 0.27 0.33 1];
fb=[0 0.28 0.32 1];
fc=[0 0.29 0.31 1];
fd=[0 0.295 0.305 1];
a0=[1 1 0 0];
n=81;
ba = remez(n,fa,a0,w0);
bb = remez(n,fb,a0,w0);
bc = remez(n,fc,a0,w0);
bd = remez(n,fd,a0,w0);
[ha,w]=freqz(ba);
[hb,w]=freqz(bb);
[hc,w]=freqz(bc);
[hd,w]=freqz(bd);
figure
plot(w,(abs(ha)))
hold on
plot(w,(abs(hb)))
plot(w,(abs(hc)))
plot(w,(abs(hd)))
hold off
xlabel('frequency(pi)')
ylabel('|H|')
title('Frequency response')
legend('wp=0.27pi,ws=0.33pi','wp=0.28pi,ws=0.32pi','wp=0.29pi,ws=0.31pi','wp=0.295pi,ws=0.305pi')

figure
plot(ba)
hold on
plot(bb)
plot(bc)
plot(bd)
hold off
xlabel('n')
ylabel('h')
title('Impulse response')
legend('wp=0.27pi,ws=0.33pi','wp=0.28pi,ws=0.32pi','wp=0.29pi,ws=0.31pi','wp=0.295pi,ws=0.305pi')


function d=dB(x)
d=20*log10(x);
end
