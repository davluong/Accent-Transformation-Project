clear
w0=[1 10];
f0=[0 0.3 0.394 1];
a0=[1 1 0 0];
n=51;
n1=81;
b = remez(n,f0,a0,w0);
b1 = remez(n1,f0,a0,w0);
[h,w]=freqz(b);
[h1,w1]=freqz(b1);
plot(w,dB(abs(h)))
hold on
plot(w1,dB(abs(h1)))
hold off
xlabel('frequency(pi)')
ylabel('|H|(dB)')
title('Frequency response')
legend('n=51','n=81')

function d=dB(x)
d=20*log10(x);
end
