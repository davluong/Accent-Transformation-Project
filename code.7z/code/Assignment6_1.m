clear
fs = 2;       % Sampling frequency
f = [0.31 0.38];   % Cutoff frequencies
a = [1 0];       % Desired amplitudes
% Compute deviations
dev = [0.018 0.004]; 
[n,fo,ao,w0] = remezord(f,a,dev,fs);


b = remez(n,fo,ao,w0);
b1 = remez(n+1,fo,ao,w0);
[h,w]=freqz(b,1,1024,fs);
[h1,w1]=freqz(b1,1,1024,fs);
figure
plot(w,abs(h))
hold on
plot(w1,abs(h1))
hold off
title('Frequency response')
xlabel('frequency(pi)')
legend('n=57','n=58')
figure
plot(w,unwrap(angle(h)))
hold on
plot(w1,unwrap(angle(h1)))
hold off
title('Phase vs Frequency')
legend('n=57','n=58')
xlabel('frequency(pi)')
figure
plot(b)
hold on
plot(b1)
hold off
title('impulse response')
legend('n=57','n=58')

