function p=recph(M,file)%recognize phonemes
%This function calculates the probability of the phonemes appears at
%certain time in a test sentence(Recorded in 'file')

%Read the data from file and plot it in time domain
[test,fs]=audioread(file);
figure
s=size(test,1);
t=linspace(0,s/fs,s);
plot(t,test)
xlabel('time(s)')
title(['time sequence of ',' ',file])

%preprocess the test data with the same bandpass filter
c1=300;
c2=3700;
[b,a] = butter(4,[2*c1/fs,2*c2/fs],'bandpass');
test=filter(b,a,test);

%Obtain the MFCC coefficients of the test file and plot them
[coeffs,delta,deltaDelta,loc] = mfcc(test,fs,'WindowLength',round(fs*0.1),'OverLapLength',round(fs*0.05));
tcoe=coeffs;
tc=cs(tcoe);%Mark the silence part of the sentence
tcoe=tcoe(:,2:13);%Only the 2nd to the 13th of the MFCC coefficients are useful
figure
t=linspace(0,s/fs,size(tcoe,1));
y=1:12;
size(tcoe)
size(y)
size(t)
contourf(t,y,tcoe')
xlabel('time(s)')
title(['MFCC spectrogram of ',file])

%Predict the probility of the phoneme appearing at each time point
p=pdf(M,tcoe);
t=linspace(0,s/fs,size(p,1));
p(isnan(p))=0;
p=tc.*p;
figure
plot(t,log10(p))
xlabel('time(s)')
ylabel('log10(Probility)')
title(['Probility of the appearance of the phoneme at t(s)'])
end